import Foundation
import SwiftUI
import Combine

class StoreViewModel: ObservableObject {
    @Published var tiendas: [TiendaInfo] = []
    @Published var tiendaSeleccionada: TiendaInfo?
    @Published var isLoading: Bool = false
    
    // Polimorfismo y Secciones Activas
    @Published var currentProjectType: ProjectType = .remodelacion
    @Published var activeSections: [String] = []
    @Published var tnPhaseTab: TNPhaseTab = .planeacion
    
    // Datos de Tienda Nueva
    @Published var tnActivities: [TNActivityItem] = []
    @Published var isLoadingTNActivities: Bool = false
    
    // Catálogo General
    @Published var catalog: [CatalogItem] = []
    
    var catalogCategories: [String] {
        Array(Set(catalog.map { $0.category }.filter { !$0.isEmpty })).sorted()
    }
    
    func catalogTypes(for category: String) -> [String] {
        Array(Set(catalog.filter { $0.category == category }.map { $0.type }.filter { !$0.isEmpty })).sorted()
    }
    
    // 1. CARGAR TIENDAS ASIGNADAS DESDE GOOGLE SHEETS
    func cargarTiendas(para usuario: Usuario) {
        isLoading = true
        let params: [String: String] = [
            "username": usuario.usuario,
            "role": usuario.rol.rawValue,
            "centro": usuario.centro,
            "coordinacion": usuario.coordinacion
        ]
        
        NetworkService.shared.get(action: "GET_PROJECTS", queryParams: params) { [weak self] result in
            self?.isLoading = false
            switch result {
            case .success(let json):
                if let projectArray = json["projects"] as? [[String: Any]] {
                    var loaded: [TiendaInfo] = []
                    for p in projectArray {
                        loaded.append(TiendaInfo(
                            storeId: p["storeId"] as? String ?? "",
                            nombre: p["name"] as? String ?? "",
                            spreadsheetId: p["spreadsheetId"] as? String ?? "",
                            residente: p["residente"] as? String ?? "",
                            residenteApoyo: p["residenteApoyo"] as? String ?? "",
                            encargadosMontaje: p["encargadosMontaje"] as? String ?? "",
                            gerente: p["gerente"] as? String ?? "",
                            centro: p["centro"] as? String ?? "",
                            coordinacion: p["coordinacion"] as? String ?? "",
                            status: p["status"] as? String ?? "Activo",
                            region: p["region"] as? String ?? "",
                            macroStartDate: p["macroStartDate"] as? String ?? "",
                            macroEndDate: p["macroEndDate"] as? String ?? "",
                            realRatio: p["realRatio"] as? Double ?? 0.0,
                            plannedRatio: p["plannedRatio"] as? Double ?? 0.0,
                            nextMilestonePhase: p["nextMilestonePhase"] as? String ?? "ETAPA PRELIMINAR"
                        ))
                    }
                    self?.tiendas = loaded
                    if self?.tiendaSeleccionada == nil {
                        self?.seleccionarTienda(loaded.first)
                    }
                }
            case .failure(let error):
                print("Error al cargar tiendas: \(error.localizedDescription)")
            }
        }
    }
    
    // 2. SELECCIONAR TIENDA Y DETECTAR TIPO DE PROYECTO
    func seleccionarTienda(_ tienda: TiendaInfo?) {
        self.tiendaSeleccionada = tienda
        guard let t = tienda, !t.spreadsheetId.isEmpty else { return }
        
        // Consultar Metadatos (Detecta Remodelación vs Tienda Nueva)
        NetworkService.shared.get(action: "GET_PROJECT_METADATA", queryParams: ["spreadsheetId": t.spreadsheetId]) { [weak self] result in
            switch result {
            case .success(let json):
                let tipoRaw = json["tipo"] as? String ?? "REMODELACION"
                let secciones = json["secciones"] as? [String] ?? []
                
                self?.currentProjectType = (tipoRaw == "TIENDA_NUEVA") ? .tiendaNueva : .remodelacion
                self?.activeSections = secciones
                
                if self?.currentProjectType == .tiendaNueva {
                    self?.cargarActividadesTN(spreadsheetId: t.spreadsheetId)
                }
            case .failure(let error):
                print("Error al leer metadatos de tienda: \(error)")
            }
        }
    }
    
    // 3. CARGAR ACTIVIDADES DE TIENDA NUEVA
    func cargarActividadesTN(spreadsheetId: String) {
        isLoadingTNActivities = true
        NetworkService.shared.get(action: "GET_TN_ACTIVITIES", queryParams: ["spreadsheetId": spreadsheetId]) { [weak self] result in
            self?.isLoadingTNActivities = false
            switch result {
            case .success(let json):
                if let actsRaw = json["activities"] as? [[String: Any]] {
                    var loaded: [TNActivityItem] = []
                    for a in actsRaw {
                        loaded.append(TNActivityItem(
                            rowIndex: a["rowIndex"] as? Int ?? 0,
                            centro: a["centro"] as? String ?? "",
                            categoria: a["categoria"] as? String ?? "",
                            actividad: a["actividad"] as? String ?? "",
                            mobiliario: a["mobiliario"] as? String ?? "",
                            meta: a["meta"] as? Int ?? 0,
                            avanceReal: a["avanceReal"] as? Int ?? 0,
                            equipoResponsable: a["equipoResponsable"] as? String ?? "",
                            diaMontaje: a["diaMontaje"] as? Int ?? 0,
                            fechaInicio: a["fechaInicio"] as? String ?? "",
                            fechaFin: a["fechaFin"] as? String ?? "",
                            duracionDias: a["duracionDias"] as? Int ?? 1
                        ))
                    }
                    self?.tnActivities = loaded
                }
            case .failure(let error):
                print("Error al cargar actividades TN: \(error)")
            }
        }
    }
    
    // 4. ACTUALIZAR AVANCE EN SITIO (Columna I de Sheets)
    func updateTNAvance(item: TNActivityItem, nuevoAvance: Int) {
        guard let t = tiendaSeleccionada, !t.spreadsheetId.isEmpty else { return }
        
        if let idx = tnActivities.firstIndex(where: { $0.id == item.id }) {
            tnActivities[idx].avanceReal = nuevoAvance
        }
        
        let payload: [String: Any] = [
            "spreadsheetId": t.spreadsheetId,
            "centro": item.centro,
            "rowIndex": item.rowIndex,
            "nuevoAvance": nuevoAvance
        ]
        NetworkService.shared.post(action: "UPDATE_TN_ACTIVITY_AVANCE", payload: payload) { _ in }
    }
    
    // 5. PROGRAMAR DÍA Y EQUIPO (Columnas P y Q de Sheets)
    func updateTNSchedule(items: [TNActivityItem], nuevoDia: Int, nuevoEquipo: String) {
        guard let t = tiendaSeleccionada, !t.spreadsheetId.isEmpty else { return }
        
        for target in items {
            if let idx = tnActivities.firstIndex(where: { $0.id == target.id }) {
                tnActivities[idx].diaMontaje = nuevoDia
                tnActivities[idx].equipoResponsable = nuevoEquipo
            }
        }
        
        let updatesPayload = items.map { [
            "centro": $0.centro,
            "rowIndex": $0.rowIndex,
            "diaMontaje": nuevoDia,
            "equipoResponsable": nuevoEquipo,
            "duracionDias": $0.duracionDias
        ] }
        
        let payload: [String: Any] = [
            "spreadsheetId": t.spreadsheetId,
            "updates": updatesPayload
        ]
        NetworkService.shared.post(action: "UPDATE_TN_SCHEDULE", payload: payload) { _ in }
    }
    
    func setTNActivityBlocked(item: TNActivityItem, motivo: String) {
        if let idx = tnActivities.firstIndex(where: { $0.id == item.id }) {
            tnActivities[idx].motivoBloqueo = motivo
        }
    }
}


