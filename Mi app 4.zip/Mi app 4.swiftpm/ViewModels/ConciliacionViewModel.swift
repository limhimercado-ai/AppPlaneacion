//  ConciliacionViewModel.swift
//  AppRemodelacion
//  Gestión de Insumos, Conciliación y Vales de Salida
//

import Foundation
import Combine

class ConciliacionViewModel: ObservableObject {
    @Published var insumos: [InsumoConciliacion] = []
    @Published var valesEmitidos: [ValeSalida] = []
    @Published var busqueda: String = ""
    @Published var isLoading: Bool = false
    
    var insumosFiltrados: [InsumoConciliacion] {
        if busqueda.isEmpty { return insumos }
        return insumos.filter {
            $0.descripcion.localizedCaseInsensitiveContains(busqueda) ||
            $0.codigo.localizedCaseInsensitiveContains(busqueda)
        }
    }
    
    func cargarInsumos(tiendaID: String) {
        isLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            self?.isLoading = false
            self?.insumos = [
                InsumoConciliacion(id: "INS-01", codigo: "ELE-001", descripcion: "Cable Cobre Calibre 12 THHN", unidad: "Metros", cantidadTeorica: 500.0, cantidadInstalada: 320.0, cantidadAlmacen: 150.0, precioUnitario: 24.50, categoria: "Eléctrico"),
                InsumoConciliacion(id: "INS-02", codigo: "TAB-002", descripcion: "Placa Tablaroca ST 1/2 1.22x2.44", unidad: "Piezas", cantidadTeorica: 120.0, cantidadInstalada: 115.0, cantidadAlmacen: 5.0, precioUnitario: 310.00, categoria: "Acabados"),
                InsumoConciliacion(id: "INS-03", codigo: "LUM-003", descripcion: "Luminaria Panel LED 60x60 40W", unidad: "Piezas", cantidadTeorica: 45.0, cantidadInstalada: 10.0, cantidadAlmacen: 35.0, precioUnitario: 850.00, categoria: "Iluminación")
            ]
        }
    }
    
    func emitirValeSalida(tiendaID: String, residente: String, contratista: String, items: [ValeSalida.ItemVale]) {
        let nuevoVale = ValeSalida(
            id: UUID().uuidString,
            folio: "VALE-\(Int.random(in: 1000...9999))",
            tiendaID: tiendaID,
            fecha: "2026-10-20",
            residente: residente,
            contratista: contratista,
            items: items,
            firmaDigital: "FIRMA_OK"
        )
        valesEmitidos.append(nuevoVale)
        
        for item in items {
            if let idx = insumos.firstIndex(where: { $0.codigo == item.codigoInsumo }) {
                insumos[idx].cantidadAlmacen = max(0, insumos[idx].cantidadAlmacen - item.cantidadEntregada)
            }
        }
    }
}

