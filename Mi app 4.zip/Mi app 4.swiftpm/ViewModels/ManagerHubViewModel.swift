//  ManagerHubViewModel.swift
//  AppRemodelacion
//  Supervisión Ejecutiva Multi-Obra y Consolidación de Bases de Datos
//

import Foundation
import Combine

class ManagerHubViewModel: ObservableObject {
    @Published var resumenObras: [TiendaInfo] = []
    @Published var estaConsolidando: Bool = false
    @Published var mensajeConsolidacion: String?
    
    func cargarResumenGeneral() {
        resumenObras = [
            TiendaInfo(id: "O-101", nombre: "Tienda San Ana", tipo: "Remodelación", estado: "En Proceso", avanceFisico: 68.5, avancePresupuestal: 62.0, residenteAsignado: "Carlos Mendoza", plannerAsignado: "Sofia Ramírez", sheetURL: ""),
            TiendaInfo(id: "O-102", nombre: "Tienda Universidad", tipo: "Tienda Nueva", estado: "Contingencia", avanceFisico: 42.0, avancePresupuestal: 50.0, residenteAsignado: "Carlos Mendoza", plannerAsignado: "Sofia Ramírez", sheetURL: ""),
            TiendaInfo(id: "O-103", nombre: "Tienda Insurgentes", tipo: "Remodelación", estado: "Completado", avanceFisico: 100.0, avancePresupuestal: 98.0, residenteAsignado: "Juan Pérez", plannerAsignado: "Sofia Ramírez", sheetURL: "")
        ]
    }
    
    func ejecutarConsolidacionGlobal() {
        estaConsolidando = true
        mensajeConsolidacion = "Conectando al Hub Central de Google Sheets..."
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
            self?.mensajeConsolidacion = "Sincronizando 3 libros individuales..."
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) { [weak self] in
            self?.estaConsolidando = false
            self?.mensajeConsolidacion = "✅ Consolidación completada exitosamente en el Hub Central."
        }
    }
}

