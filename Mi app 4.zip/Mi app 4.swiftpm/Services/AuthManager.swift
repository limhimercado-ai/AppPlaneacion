//  AuthManager.swift
//  AppRemodelacion
//  Gestión de Sesión, Credenciales y Perfil de Usuario
//

import Foundation
import Combine

class AuthManager: ObservableObject {
    static let shared = AuthManager()
    
    @Published var currentUser: Usuario?
    @Published var isAuthenticated: Bool = false
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false
    
    private let userDefaultsKey = "saved_user_session"
    
    private init() {
        loadSession()
    }
    
    func login(usuario: String, contrasena: String) {
        let uLimpio = usuario.trimmingCharacters(in: .whitespacesAndNewlines)
        let pLimpio = contrasena.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !uLimpio.isEmpty, !pLimpio.isEmpty else {
            self.errorMessage = "Ingresa usuario y contraseña."
            return
        }
        
        isLoading = true
        errorMessage = nil
        
        let payload: [String: Any] = [
            "username": uLimpio,
            "password": pLimpio
        ]
        
        // Petición real al Hub Central de Google Apps Script
        NetworkService.shared.request(action: "LOGIN", payload: payload) { [weak self] (result: Result<LoginResponse, Error>) in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success(let response):
                    if response.status == "success", let rawUser = response.user {
                        // Mapeo del rol devuelto por la base de datos
                        let rolString = rawUser.role ?? ""
                        let rolMapeado: RolUsuario
                        switch rolString {
                        case "Gerente Sr":
                            rolMapeado = .gerenteSr
                        case "Gerente":
                            rolMapeado = .planner
                        default:
                            rolMapeado = .residente
                        }
                        
                        let tiendas = rawUser.assignedStore?
                            .components(separatedBy: ",")
                            .map { $0.trimmingCharacters(in: .whitespaces) }
                            .filter { !$0.isEmpty } ?? []
                        
                        let nuevoUsuario = Usuario(
                            usuario: rawUser.username ?? uLimpio,
                            nombre: rawUser.name ?? "Usuario",
                            rol: rolMapeado,
                            centro: rawUser.centro ?? "",
                            coordinacion: rawUser.coordinacion ?? "",
                            obrasAsignadas: tiendas
                        )
                        
                        self?.setSession(nuevoUsuario)
                    } else {
                        self?.errorMessage = response.message ?? "Credenciales incorrectas."
                    }
                    
                case .failure(let error):
                    self?.errorMessage = "Error de conexión: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func logout() {
        currentUser = nil
        isAuthenticated = false
        UserDefaults.standard.removeObject(forKey: userDefaultsKey)
    }
    
    private func setSession(_ user: Usuario) {
        self.currentUser = user
        self.isAuthenticated = true
        if let encoded = try? JSONEncoder().encode(user) {
            UserDefaults.standard.set(encoded, forKey: userDefaultsKey)
        }
    }
    
    private func loadSession() {
        if let data = UserDefaults.standard.data(forKey: userDefaultsKey),
           let user = try? JSONDecoder().decode(Usuario.self, from: data) {
            self.currentUser = user
            self.isAuthenticated = true
        }
    }
}

