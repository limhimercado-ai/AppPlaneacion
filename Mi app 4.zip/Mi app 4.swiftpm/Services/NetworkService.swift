import Foundation

enum NetworkError: Error, LocalizedError {
    case invalidURL
    case noData
    case decodingError
    case serverError(String)
    
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "La URL proporcionada no es válida."
        case .noData: return "El servidor no devolvió datos."
        case .decodingError: return "Error al procesar la respuesta del servidor."
        case .serverError(let msg): return "Error en el servidor: \(msg)"
        }
    }
}

class NetworkService {
    static let shared = NetworkService()
    private init() {}
    
    // Pega aquí la URL de tu implementación web de Apps Script (terminada en /exec)
    var baseURL: String = "https://script.google.com/macros/s/AKfycbyoeO9rgL9Lrc0ihA-tRwQ2UK4WE7Vtc_8mnfU3WLCXyU6DggYE33WmiqagV5B-b6qc/exec"
    
    // 1. PETICIÓN GET (Consultas de catálogos, proyectos y hojas)
    func get(action: String, queryParams: [String: String] = [:], completion: @escaping (Result<[String: Any], Error>) -> Void) {
        guard var components = URLComponents(string: baseURL) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var items = [URLQueryItem(name: "action", value: action)]
        for (k, v) in queryParams {
            items.append(URLQueryItem(name: k, value: v))
        }
        components.queryItems = items
        
        guard let url = components.url else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                DispatchQueue.main.async { completion(.failure(error)) }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async { completion(.failure(NetworkError.noData)) }
                return
            }
            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    DispatchQueue.main.async { completion(.success(json)) }
                } else {
                    DispatchQueue.main.async { completion(.failure(NetworkError.decodingError)) }
                }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }.resume()
    }
    
    // 2. PETICIÓN POST (Altas, avances, asignaciones y vales)
    func post(action: String, payload: [String: Any], completion: @escaping (Result<[String: Any], Error>) -> Void) {
        guard let url = URL(string: baseURL) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        var bodyData = payload
        bodyData["action"] = action
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: bodyData, options: [])
        } catch {
            completion(.failure(error))
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                DispatchQueue.main.async { completion(.failure(error)) }
                return
            }
            guard let data = data else {
                DispatchQueue.main.async { completion(.failure(NetworkError.noData)) }
                return
            }
            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    DispatchQueue.main.async { completion(.success(json)) }
                } else {
                    DispatchQueue.main.async { completion(.failure(NetworkError.decodingError)) }
                }
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }.resume()
    }
}


