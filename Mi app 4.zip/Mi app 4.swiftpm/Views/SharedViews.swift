//  SharedViews.swift
//  AppRemodelacion
//  Componentes Reutilizables de Interfaz y Pantalla de Login
//

import SwiftUI

// MARK: - LoginView
struct LoginView: View {
    @StateObject private var auth = AuthManager.shared
    @State private var usuarioText: String = ""
    @State private var passText: String = ""
    
    var body: some View {
        VStack(spacing: 25) {
            Spacer()
            
            Image(systemName: "building.2.crop.circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 90, height: 90)
                .foregroundColor(.blue)
            
            Text("Control de Remodelaciones")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Ingresa tus credenciales corporativas")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            VStack(spacing: 15) {
                TextField("Usuario (ej. residente, planner, gerente)", text: $usuarioText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.none)
                
                SecureField("Contraseña", text: $passText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            .frame(maxWidth: 350)
            
            if let error = auth.errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
            }
            
            Button(action: {
                auth.login(usuario: usuarioText, contrasena: passText)
            }) {
                HStack {
                    if auth.isLoading {
                        ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Text("Iniciar Sesión")
                            .fontWeight(.semibold)
                    }
                }
                .frame(maxWidth: 350, minHeight: 45)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .disabled(auth.isLoading)
            
            Spacer()
        }
        .padding()
    }
}

// MARK: - StatusPillView
struct StatusPillView: View {
    let titulo: String
    let color: Color
    
    var body: some View {
        Text(titulo)
            .font(.caption)
            .fontWeight(.bold)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(color.opacity(0.15))
            .foregroundColor(color)
            .cornerRadius(12)
    }
}

