//  ManagerViews.swift
//  AppRemodelacion
//  Vistas Ejecutivas de Supervisión Multi-Obra y Consolidación
//

import SwiftUI

struct ManagerDashboardView: View {
    @StateObject var managerVM = ManagerHubViewModel()
    @EnvironmentObject var auth: AuthManager
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Button(action: {
                        managerVM.ejecutarConsolidacionGlobal()
                    }) {
                        HStack {
                            Image(systemName: "arrow.triangle.2.circlepath")
                            Text("Consolidar Hub Central (Google Sheets)")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    
                    if let msg = managerVM.mensajeConsolidacion {
                        Text(msg)
                            .font(.caption)
                            .foregroundColor(.purple)
                            .padding(.horizontal)
                    }
                    
                    ForEach(managerVM.resumenObras) { tienda in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text(tienda.nombre)
                                    .font(.headline)
                                Spacer()
                                StatusPillView(titulo: tienda.estado, color: tienda.statusColor)
                            }
                            
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("Avance Físico")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                    Text("\(String(format: "%.1f", tienda.avanceFisico))%")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.blue)
                                }
                                Spacer()
                                VStack(alignment: .leading) {
                                    Text("Avance Presupuesto")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                    Text("\(String(format: "%.1f", tienda.avancePresupuestal))%")
                                        .font(.title3)
                                        .fontWeight(.bold)
                                        .foregroundColor(.green)
                                }
                                Spacer()
                                VStack(alignment: .leading) {
                                    Text("Residente")
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                    Text(tienda.residenteAsignado)
                                        .font(.subheadline)
                                }
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(radius: 2)
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .navigationTitle("Hub Gerencial")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cerrar Sesión") {
                        auth.logout()
                    }
                }
            }
            .onAppear {
                managerVM.cargarResumenGeneral()
            }
        }
    }
}

