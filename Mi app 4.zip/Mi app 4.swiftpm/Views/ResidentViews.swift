//  ResidentViews.swift
//  AppRemodelacion
//  Vistas de Captura de Campo para el Residente de Obra
//

import SwiftUI

struct ResidentHomeView: View {
    @EnvironmentObject var storeVM: StoreViewModel
    @EnvironmentObject var auth: AuthManager
    @State private var tabSeleccionado = 0
    
    var body: some View {
        NavigationView {
            VStack {
                if let tienda = storeVM.tiendaSeleccionada {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(tienda.nombre)
                                .font(.title2)
                                .fontWeight(.bold)
                            Text("ID: \(tienda.id) | \(tienda.tipo)")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        StatusPillView(titulo: tienda.estado, color: tienda.statusColor)
                    }
                    .padding()
                    .background(Color(.systemGroupedBackground))
                }
                
                Picker("Módulo", selection: $tabSeleccionado) {
                    Text("Avances").tag(0)
                    Text("Conciliación").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                
                if tabSeleccionado == 0 {
                    PhaseTimelineView()
                } else {
                    MaterialConciliacionView()
                }
            }
            .navigationTitle("Panel Residente")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cerrar Sesión") {
                        auth.logout()
                    }
                }
            }
            .onAppear {
                if let usuario = auth.currentUser {
                    storeVM.cargarTiendas(para: usuario)
                }
            }
        }
    }
}

struct PhaseTimelineView: View {
    @EnvironmentObject var storeVM: StoreViewModel
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(storeVM.etapasDisponibles, id: \.self) { etapa in
                            Button(action: { storeVM.etapaSeleccionada = etapa }) {
                                Text(etapa)
                                    .font(.subheadline)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(storeVM.etapaSeleccionada == etapa ? Color.blue : Color(.systemGray5))
                                    .foregroundColor(storeVM.etapaSeleccionada == etapa ? .white : .primary)
                                    .cornerRadius(15)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                
                ForEach(storeVM.actividadesFiltradas) { act in
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(act.codigoSubetapa)
                                .fontWeight(.bold)
                                .foregroundColor(.blue)
                            Text(act.descripcion)
                                .fontWeight(.medium)
                            Spacer()
                            StatusPillView(titulo: act.estado, color: act.statusColor)
                        }
                        
                        ProgressView(value: act.porcentajeAvance, total: 100.0)
                            .accentColor(act.statusColor)
                        
                        HStack {
                            Text("Avance: \(Int(act.porcentajeAvance))%")
                                .font(.caption)
                                .foregroundColor(.gray)
                            Spacer()
                            Text("Resp: \(act.responsable)")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color(.white))
                    .cornerRadius(10)
                    .shadow(radius: 1)
                    .padding(.horizontal)
                }
            }
            .padding(.vertical)
        }
    }
}

struct MaterialConciliacionView: View {
    @StateObject var concVM = ConciliacionViewModel()
    @EnvironmentObject var storeVM: StoreViewModel
    
    var body: some View {
        VStack {
            TextField("Buscar insumo por código o nombre...", text: $concVM.busqueda)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)
            
            List(concVM.insumosFiltrados) { insumo in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(insumo.codigo)
                            .fontWeight(.bold)
                        Spacer()
                        Text(insumo.categoria)
                            .font(.caption)
                            .padding(4)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(4)
                    }
                    Text(insumo.descripcion)
                        .font(.subheadline)
                    
                    HStack {
                        Text("Teórico: \(Int(insumo.cantidadTeorica)) \(insumo.unidad)")
                        Spacer()
                        Text("Instalado: \(Int(insumo.cantidadInstalada))")
                        Spacer()
                        Text("Almacén: \(Int(insumo.cantidadAlmacen))")
                            .foregroundColor(.green)
                            .fontWeight(.bold)
                    }
                    .font(.caption)
                    .foregroundColor(.gray)
                }
            }
        }
        .onAppear {
            if let tienda = storeVM.tiendaSeleccionada {
                concVM.cargarInsumos(tiendaID: tienda.id)
            }
        }
    }
}

