//  AppMain.swift
//  AppRemodelacion
//  Punto de Entrada Principal de la Aplicación
//

import SwiftUI

@main
struct AppRemodelacionApp: App {
    @StateObject private var auth = AuthManager.shared
    @StateObject private var storeVM = StoreViewModel()
    
    var body: some Scene {
        WindowGroup {
            Group {
                if !auth.isAuthenticated {
                    LoginView()
                } else if auth.currentUser?.rol == .residente {
                    ResidentHomeView()
                        .environmentObject(storeVM)
                        .environmentObject(auth)
                } else {
                    ManagerDashboardView()
                        .environmentObject(storeVM)
                        .environmentObject(auth)
                }
            }
        }
    }
}

