import Foundation
import SwiftUI

// MARK: - ROLES DE USUARIO
enum RolUsuario: String, Codable, CaseIterable, Identifiable {
    case residente = "Residente"
    case planner = "Gerente"
    case gerenteSr = "Gerente Sr"
    
    var id: String { rawValue }
    
    var badgeColor: Color {
        switch self {
        case .residente: return .blue
        case .planner: return .orange
        case .gerenteSr: return .purple
        }
    }
}

// MARK: - USUARIO DE SESIÓN
struct Usuario: Identifiable, Codable, Hashable {
    var id: String { usuario }
    let usuario: String
    let nombre: String
    let rol: RolUsuario
    let centro: String
    let coordinacion: String
    let obrasAsignadas: [String]
}

// DTOs de Autenticación
struct LoginResponse: Decodable {
    let status: String
    let message: String?
    let user: ServerUserDTO?
}

struct ServerUserDTO: Decodable {
    let username: String?
    let name: String?
    let role: String?
    let assignedStore: String?
    let centro: String?
    let coordinacion: String?
}

// MARK: - TIPOS DE PROYECTO
enum ProjectType: String, Codable, Equatable {
    case remodelacion = "REMODELACION"
    case tiendaNueva = "TIENDA_NUEVA"
}

enum TNPhaseTab: String, CaseIterable {
    case planeacion = "Planeación"
    case montaje = "Montaje"
}

// MARK: - MODELO DE PROYECTO / TIENDA REAL (Google Sheets)
struct TiendaInfo: Identifiable, Codable, Hashable {
    var id: String { storeId.isEmpty ? UUID().uuidString : storeId }
    var storeId: String
    var nombre: String
    var spreadsheetId: String
    var residente: String
    var residenteApoyo: String
    var encargadosMontaje: String
    var gerente: String
    var centro: String
    var coordinacion: String
    var status: String
    var region: String
    var macroStartDate: String
    var macroEndDate: String
    var realRatio: Double
    var plannedRatio: Double
    var nextMilestonePhase: String
    
    var statusColor: Color {
        let gap = plannedRatio - realRatio
        if gap > 0.10 { return .red }
        if gap > 0.04 { return .orange }
        return .green
    }
}

// MARK: - ACTIVIDADES DE TIENDA NUEVA
struct TNActivityItem: Identifiable, Codable, Hashable {
    var id: String { "\(rowIndex)_\(centro)_\(categoria)_\(mobiliario)" }
    let rowIndex: Int
    let centro: String
    let categoria: String
    let actividad: String
    let mobiliario: String
    var meta: Int
    var avanceReal: Int
    var equipoResponsable: String
    var diaMontaje: Int
    let fechaInicio: String
    let fechaFin: String
    var duracionDias: Int
    var motivoBloqueo: String = ""
    
    var isProgramada: Bool { diaMontaje > 0 }
    var isCompletada: Bool { meta > 0 && avanceReal >= meta }
    var isBloqueada: Bool { !motivoBloqueo.isEmpty }
    
    var avancePorcentaje: Double {
        guard meta > 0 else { return 0.0 }
        return Double(avanceReal) / Double(meta)
    }
    
    var displayName: String {
        let mob = mobiliario.trimmingCharacters(in: .whitespacesAndNewlines)
        let act = actividad.trimmingCharacters(in: .whitespacesAndNewlines)
        if !mob.isEmpty && !mob.uppercased().contains("HABILITADO") { return mob }
        if !act.isEmpty && !act.uppercased().contains("HABILITADO") { return act }
        return mob.isEmpty ? (act.isEmpty ? "Mobiliario" : act) : mob
    }
    
    var displaySubtype: String {
        displayName == mobiliario ? (actividad.isEmpty ? categoria : actividad) : categoria
    }
    
    func isRetrasada(diaActualObra: Int) -> Bool {
        isProgramada && !isCompletada && diaMontaje < diaActualObra
    }
}

// MARK: - CATÁLOGO GENERAL
struct CatalogItem: Identifiable, Codable, Hashable {
    var id: String { itemId.isEmpty ? "\(category)_\(type)_\(activity)" : itemId }
    let category: String
    let type: String
    let activity: String
    let itemId: String
}

// MARK: - ACTIVIDAD DE REMODELACIÓN
struct ActividadRemodelacion: Identifiable, Codable, Hashable {
    var id: String { "\(sheetName)_\(rowIndex)" }
    let sheetName: String
    let rowIndex: Int
    let category: String
    let type: String
    let activity: String
    let itemId: String
    var meta: Int
    var progress: Int
    var description: String
    let team: String
    var startDate: String
    var endDate: String
    var blockedReason: String
}


